const User = require('../models/userModel'); // Import your User model

// Get user profile
exports.getProfile = async (req, res) => {
    try {
        // Find the user by ID from the JWT
        const user = await User.findById(req.userId).select('-password'); // Exclude password from the response
        if (!user) {
            return res.status(404).render('error', { error: { message: 'User not found.' } });
        }
        res.status(200).render('profile', { user }); // Render profile page with user data
    } catch (error) {
        console.error('Error fetching user profile:', error);
        res.status(500).render('error', { error: { message: 'Server error fetching profile.' } });
    }
};

// Update user profile
exports.updateProfile = async (req, res) => {
    const { name, email } = req.body; // Get the updated data from the request
    try {
        // Update user information
        const updatedUser = await User.findByIdAndUpdate(
            req.userId,
            { name, email },
            { new: true, runValidators: true } // Return the updated document and run validators
        ).select('-password'); // Exclude password from the response

        if (!updatedUser) {
            return res.status(404).render('error', { error: { message: 'User not found.' } });
        }

        res.status(200).render('profile', { user: updatedUser, message: 'Profile updated successfully.' });
    } catch (error) {
        console.error('Error updating user profile:', error);
        res.status(400).render('error', { error: { message: 'Error updating profile. Please check your input.' } });
    }
};
