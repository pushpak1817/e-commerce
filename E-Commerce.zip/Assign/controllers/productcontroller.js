const Product = require('../models/productModel'); // Import the Product model

// Get all products
exports.getAllProducts = async (req, res) => {
    try {
        const products = await Product.find(); // Fetch all products from the database
        res.status(200).json(products); // Return products as JSON
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ message: 'Server error fetching products.' });
    }
};

// Get a product by ID
exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id); // Find product by ID
        if (!product) {
            return res.status(404).json({ message: 'Product not found.' });
        }
        res.status(200).json(product); // Return product as JSON
    } catch (error) {
        console.error('Error fetching product:', error);
        res.status(500).json({ message: 'Server error fetching product.' });
    }
};

// Create a new product
exports.createProduct = async (req, res) => {
    const newProduct = new Product(req.body); // Create a new product instance

    try {
        const savedProduct = await newProduct.save(); // Save product to the database
        res.status(201).json(savedProduct); // Return created product
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(400).json({ message: 'Error creating product. Please check your input.' });
    }
};

// Update an existing product
exports.updateProduct = async (req, res) => {
    try {
        const updatedProduct = await Product.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true } // Return the updated document and run validators
        );

        if (!updatedProduct) {
            return res.status(404).json({ message: 'Product not found.' });
        }
        res.status(200).json(updatedProduct); // Return updated product
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(400).json({ message: 'Error updating product. Please check your input.' });
    }
};

// Delete a product
exports.deleteProduct = async (req, res) => {
    try {
        const deletedProduct = await Product.findByIdAndDelete(req.params.id); // Delete product by ID
        if (!deletedProduct) {
            return res.status(404).json({ message: 'Product not found.' });
        }
        res.status(200).json({ message: 'Product deleted successfully.' }); // Return success message
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ message: 'Server error deleting product.' });
    }
};
