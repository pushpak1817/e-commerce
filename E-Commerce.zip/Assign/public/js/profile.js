res.render('profile', { user });
