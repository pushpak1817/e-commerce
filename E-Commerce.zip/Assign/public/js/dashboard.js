res.render('dashboard', { 
    user, 
    orders, 
    weather, 
    exchangeRates 
  });
  