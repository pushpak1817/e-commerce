// Import the required modules
const app = require('./app'); // Import your Express application
const dotenv = require('dotenv'); // Import dotenv to load environment variables
const mongoose = require('mongoose'); // Import mongoose for MongoDB connection

// Load environment variables
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log('Connected to MongoDB');
}).catch((error) => {
    console.error('MongoDB connection error:', error);
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
