const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');
const { verifyToken } = require('../controllers/authController'); // Import the token verification middleware

// Define routes
router.get('/', verifyToken, profileController.getProfile); // Get user profile
router.put('/', verifyToken, profileController.updateProfile); // Update user profile

module.exports = router; // Export the router
