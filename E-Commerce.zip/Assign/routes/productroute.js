const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController'); // Adjust the path as necessary

// Define routes
router.get('/', productController.getAllProducts); // Get all products
router.get('/:id', productController.getProductById); // Get product by ID
router.post('/', productController.createProduct); // Create a new product
router.put('/:id', productController.updateProduct); // Update an existing product
router.delete('/:id', productController.deleteProduct); // Delete a product

module.exports = router; // Export the router
